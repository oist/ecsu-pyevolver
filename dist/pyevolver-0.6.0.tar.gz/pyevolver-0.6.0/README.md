# pyevolver

1. Create and activate python virtual environment, and upgrade pip
    - `python3 -m venv .venv`
    - `source .venv/bin/activate`
    - `python -m pip install --upgrade pip`
2. Install pyevolver:
    - `pip install git+https://github.com/oist/ecsu-pyevolver@0.4.3`